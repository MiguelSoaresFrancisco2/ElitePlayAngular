import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { ActivatedRoute, RouterModule } from '@angular/router';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, RouterModule], // Inclui RouterModule para roteamento
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
})
export class ProductListComponent implements OnInit {
  products: any[] = []; // Lista de produtos
  category: string | null = null; // Categoria filtrada (opcional)
  searchQuery: string | null = null; // Filtro de pesquisa (opcional)
  error: string | null = null; // Mensagem de erro (opcional)

  constructor(private apiService: ApiService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    // Escuta os parâmetros da query string (pesquisa)
    this.route.queryParams.subscribe(params => {
      this.searchQuery = params['search'] || null;
      this.loadProducts(); // Recarrega os produtos sempre que o parâmetro muda
    });

    // Escuta os parâmetros da rota (categoria)
    this.route.params.subscribe(params => {
      this.category = params['category'] || null;
      this.loadProducts(); // Recarrega os produtos sempre que a categoria muda
    });
  }

  loadProducts(): void {
    // Caso haja uma query de pesquisa
    if (this.searchQuery) {
      this.apiService.getProductsByName(this.searchQuery).subscribe({
        next: (data) => {
          this.products = data; // Atualiza os produtos com o resultado da pesquisa
          this.error = null;
        },
        error: (err) => {
          console.error('Erro ao buscar produtos:', err);
          this.error = 'Erro ao buscar produtos.';
        },
      });
    }
    // Caso uma categoria seja fornecida
    else if (this.category) {
      this.apiService.getProductsByCategory(this.category).subscribe({
        next: (data) => {
          this.products = data; // Atualiza os produtos da categoria
          this.error = null;
        },
        error: (err) => {
          console.error('Erro ao buscar produtos por categoria:', err);
          this.error = 'Erro ao buscar produtos por categoria.';
        },
      });
    }
    // Caso nenhum filtro seja fornecido (todos os produtos)
    else {
      this.apiService.getProducts().subscribe({
        next: (data) => {
          this.products = data; // Atualiza os produtos com todos os disponíveis
          this.error = null;
        },
        error: (err) => {
          console.error('Erro ao buscar produtos:', err);
          this.error = 'Erro ao buscar produtos.';
        },
      });
    }
  }
}